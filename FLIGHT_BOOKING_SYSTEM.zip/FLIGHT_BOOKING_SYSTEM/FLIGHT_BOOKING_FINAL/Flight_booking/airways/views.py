from django.shortcuts import redirect,render
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate
from django.shortcuts import render, HttpResponse
from django.core.mail import send_mail
from .models import *
from datetime import datetime

d = {}
user_data= []
datax=[]
def signup(request):
    if request.method == "POST":
        name = request.POST['username']
        email = request.POST['mail']
        password = request.POST['password']
        if User.objects.filter(username=email).count() > 0:
            messages.error(request,"User Already Exists")
        else:
            user = User.objects.create_user(email, email, password, is_superuser=False)
            user.first_name = name
            user.save()
            global user_id 
            user_id = email
            return render(request, 'airways/home.html')
    return render(request, 'airways/signup.html')

def home(request):
    global min_date
    city = Place.objects.all()
    min_date = f"{datetime.now().date().year}-{datetime.now().date().month:02d}-{datetime.now().date().day}"
    global seat
    global count,from_loc,to_loc,depart_date_user,seat,seat_class,seat_number
    count=0
    if request.method=="POST":
        print(request.POST)
        from_loc = request.POST.get('from_loc')
        to_loc = request.POST.get('to_loc')
        depart_date_user = request.POST.get('date')
        seat = int(request.POST.get('seat'))
        seat_class = request.POST.get('class')
        from_obj = Place.objects.filter(city=from_loc)
        to_obj = Place.objects.filter(city=to_loc)
        
        if seat_class=="economy":
            flight = Flight.objects.filter(origin=from_obj[0],destination=to_obj[0],depart_date=depart_date_user,economy_booked__lte=20-seat)
            for f in flight:
                f.fare = int(f.economy_fare)

        elif seat_class=="buisness":
            flight = Flight.objects.filter(origin=from_obj[0],destination=to_obj[0],depart_date=depart_date_user,business_booked__lte=20-seat)
            for f in flight:
                f.fare = int(f.business_fare)
        else:
            flight = Flight.objects.filter(origin=from_obj[0],destination=to_obj[0],depart_date=depart_date_user,first_booked__lte=20-seat)
            for f in flight:
                f.fare = int(f.first_fare)
        d["flight"]=flight
        if flight.count()==0:
            messages.error(request,"No flights Found")
        else:
            return redirect("/flights_display/")
    return render(request,'airways/home.html',{'city':city,'min_date':min_date})

def login(request):
    if request.method=="POST":
        email=request.POST['email']
        password=request.POST['password']
        user = authenticate(username=email,password=password)
        if (email=="anuragav754@gmail.com" and password==123456):
            return redirect("/adminx")
        if user:
            global user_id
            user_id=email
            return redirect("/home")
        else:
            messages.info(request,"Wrong Credentials")
            return redirect('login')
    return render(request,"airways/login.html")

def flight_display(request):
    global seat_number,seat_price
    if request.method=="POST":
        global new_flight_id
        new_flight_id = request.POST.get('flight_id')
        if seat_class=='economy':
            seat_number = "E"+str(dict(Flight.objects.filter(Flight_id=new_flight_id).values()[0])["economy_booked"]+1)
            seat_price = dict(Flight.objects.filter(Flight_id=new_flight_id).values()[0])["economy_fare"]
        elif seat_class=='buisness':
            seat_number = "E"+str(dict(Flight.objects.filter(Flight_id=new_flight_id).values()[0])["business_booked"]+1)
            seat_price = dict(Flight.objects.filter(Flight_id=new_flight_id).values()[0])["business_fare"]
        else:
            seat_number = "E"+str(dict(Flight.objects.filter(Flight_id=new_flight_id).values()[0])["first_booked"]+1)
            seat_price = dict(Flight.objects.filter(Flight_id=new_flight_id).values()[0])["first_fare"]
        return redirect("/book/")
    return render(request,'airways/flights.html',{'flight':d["flight"]})


def booking(request):
    count=1
    if request.method=="POST":
        name = request.POST.get('name')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        aadhar = request.POST.get('aadhar')
        email = request.POST.get('email')
        number = request.POST.get('number')
        user_ticket = ticket(user_id=user_id,seat_number=seat_number, 
                             name = name, age = age, gender = str(gender),
                             aadhar = aadhar,ticket_id = str(new_flight_id+seat_number),
                             flight_id = new_flight_id, seat_class = seat_class,
                             booking_date =min_date, mobile_no = number,
                             email = email, price =seat_price)

        user_ticket.save()
        global seat
        seat-=1
        count+=1
        if seat==0:
            seat=count-1
            count-=1
            return redirect("/payment/")
        return render(request,'airways/booking.html',{'i':count,'j':seat})
    return render(request,'airways/booking.html',{'i':count,'j':seat})

def logout(request):
    return redirect("/login")

def payment(request):
    total = seat*seat_price
    print(seat,seat_price)
    if request.method=="POST":
        mail = ticket.objects.all().filter(user_id=user_id,status="pending")
        tickets = ticket.objects.filter(user_id=user_id,status="pending").update(status="confirmed")
        send_mail('Tickets from Airways',f'This/These are your tickets from airways '+str(mail),'anuragav754@gmail.com',[user_id],fail_silently=False)
        if seat_class=="economy":
            seat_booked = Flight.objects.filter(Flight_id=new_flight_id)[0].economy_booked
            Flight.objects.filter(Flight_id=new_flight_id).update(economy_booked=seat_booked+seat)
        elif seat_class=="buisness":
            seat_booked = Flight.objects.filter(Flight_id=new_flight_id)[0].business_booked
            Flight.objects.filter(Flight_id=new_flight_id).update(business_booked=seat_booked+seat)
        else:
            seat_booked = Flight.objects.filter(Flight_id=new_flight_id)[0].first_booked
            Flight.objects.filter(Flight_id=new_flight_id).update(first_booked=seat_booked+seat)
        return redirect("/final")
    return render(request,"airways/payment.html",{'total':total})

def mybooking(request):
    global datax
    datax = []
    data = ticket.objects.all().filter(user_id=user_id).values()
    for x in data:
        mydatax = {}
        mydatax["id"] = x["id"]
        mydatax["name"] = x["name"]
        mydatax["Flight_id"] = x["flight_id"]
        mydatax["seat_number"] = x["seat_number"]
        mydatax["status"] = x["status"]
        datax.append(mydatax)
    return render(request,'airways/mybooking.html',{"mydata":datax})
    
    
def adminx(request):
    place = Place.objects.all()
    return render(request,'airways/admin.html',{"city":place})
    
    
def ticketid(request):
    my_ticket_id = request.POST.get('ticket_id')
    mydata = []
    data = ticket.objects.all().filter(ticket_id=my_ticket_id).values()
    for x in data:
        mydata.append(x)
        print(x,"\n\n")
    return render(request,'airways/ticketid.html',{"mydata":mydata})
  
       
def flightid(request):
    my_flight_id = request.POST.get('flight_id')
    mydata = []
    data = ticket.objects.all().filter(flight_id=my_flight_id).values()
    for x in data:
        mydatax = {}
        mydatax["ID "] = x["id"]
        mydatax["USER ID"] = x["user_id"]
        mydatax["NAME"] = x["name"]
        mydatax["TICKET ID"] = x["ticket_id"]
        mydatax["SEAT NUMBER"] = x["seat_class"]
        mydata.append(mydatax)
    return render(request,'airways/flightid.html',{"mydata":mydata})
    
    
def deleteflight(request):
    my_flight_id = request.POST.get('flightname')
    if Flight.objects.filter(Flight_id=my_flight_id).count()==0:
        messages.error(request,"Flight not found")
    else:
        messages.success(request,"Deleted the Flight")
    Flight.objects.filter(Flight_id=my_flight_id).delete()


def final(request):
    return render(request,"airways/final.html")
    
def new_flight(request):
    
    if request.method == 'POST':
        flight_id = request.POST.get('flight_id')
        airline = request.POST.get('airline')
        origin = request.POST.get('origin')
        destination = request.POST.get('destination')
        depart_date = request.POST.get('depart_date')
        depart_time = request.POST.get('depart_time')
        duration = request.POST.get('duration')
        arrival_date = request.POST.get('arrival_date')
        arrival_time = request.POST.get('arrival_time')
        economy_fare = request.POST.get('economy_fare')
        business_fare = request.POST.get('business_fare')
        first_fare = request.POST.get('first_fare')
        flight = Flight(
            flight_id=flight_id,
            airline=airline,
            origin=origin,
            destination=destination,
            depart_date=depart_date,
            depart_time=depart_time,
            duration=duration,
            arrival_date=arrival_date,
            arrival_time=arrival_time,
            economy_fare=economy_fare,
            business_fare=business_fare,
            first_fare=first_fare
            
        )
        flight.save()
    return redirect("/home")



