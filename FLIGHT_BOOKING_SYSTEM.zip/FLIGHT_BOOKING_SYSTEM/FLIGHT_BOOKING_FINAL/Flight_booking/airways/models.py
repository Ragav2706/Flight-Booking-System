from django.db import models

class Place(models.Model):
    city = models.CharField(max_length=20)
    airport_name = models.CharField(max_length=35)
    pincode = models.IntegerField()

    def __str__(self):
        return f"{self.city}"

class Flight(models.Model):
    Flight_id = models.CharField(max_length=10)
    airline = models.CharField(max_length=64)
    origin = models.ForeignKey(Place,on_delete=models.CASCADE,related_name="origin")
    destination = models.ForeignKey(Place,on_delete=models.CASCADE,related_name="destination")
    depart_date = models.DateField()
    depart_time = models.TimeField(auto_now=False, auto_now_add=False)
    duration = models.DurationField(null=True)
    arrival_date = models.DateField()
    arrival_time = models.TimeField(auto_now=False, auto_now_add=False)
    economy_fare = models.FloatField(null=True)
    business_fare = models.FloatField(null=True)
    first_fare = models.FloatField(null=True)
    economy_booked = models.IntegerField(default=0)
    business_booked = models.IntegerField(default=0)
    first_booked = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.Flight_id}: {self.origin} to {self.destination} on {self.depart_date}"
    
SEAT_CLASS = (
    ('economy', 'Economy'),
    ('business', 'Business'),
    ('first', 'First')
)
STATUS=(
    ('PENDING','Pending'),
    ('CONFIRMED','Confirmed'),
    ('CANCELLED','Cancelled')
)

GENDER_CHOICE=(
    ('MALE','Male'),
    ('FEMALE','Female')
)
class ticket(models.Model):
    user_id = models.CharField(max_length=25,null=True)
    seat_number = models.CharField(max_length=5,default=0)
    name = models.CharField(max_length=50)
    age = models.IntegerField(null=True)
    gender = models.CharField(max_length=10,null=True)
    aadhar = models.IntegerField(null=True)
    ticket_id = models.CharField(max_length = 40)
    flight_id = models.CharField(max_length=10)
    seat_class = models.CharField(choices=SEAT_CLASS,max_length=10)
    booking_date = models.DateField()
    mobile_no = models.IntegerField()
    email = models.EmailField()
    price = models.IntegerField()
    status = models.CharField(max_length=10,default="pending")

    def __str__(self):
        return self.ticket_id


