from django.urls import path
from . import views

urlpatterns = [
    path('',views.login, name="login"),
    path('signup/', views.signup, name="signup"),
    path('login/',views.login,name="login"),
    path('home/',views.home,name="home"),
    path('flights_display/',views.flight_display,name="flight_display"),
    path('book/',views.booking),
    path('logout/',views.logout),
    path('payment/',views.payment),
    path('mybooking/',views.mybooking),
    path('adminx/',views.adminx),
    path('adminx/ticketid',views.ticketid),
    path('adminx/flightid',views.flightid),
    path('adminx/deleteflight',views.deleteflight),
    path('adminx/new_flight',views.new_flight),
    path('final/',views.final)
  
    

]
